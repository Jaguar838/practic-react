const galleryImg = [
  { id: 1, img: "../../images/ex_1.jpg", label: "PhoneBooth" },
  { id: 2, img: "../../images/ex_2.jpg", label: "FocusRoom" },
  { id: 3, img: "../../images/ex_3.jpg", label: "MeetingRoom" },
  { id: 4, img: "../../images/ex_4.jpg", label: "OpenMeetingRoom" },
];

export default galleryImg;
