export { default } from "./Warranty";
