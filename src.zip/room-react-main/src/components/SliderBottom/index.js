export { default } from "./SliderBottom";
