import img1 from "../../images/slider2.jpg";
const SliderBottom = () => {
  return (
    <div>
      <img src={img1} alt="slide2" />
    </div>
  );
};
export default SliderBottom;
