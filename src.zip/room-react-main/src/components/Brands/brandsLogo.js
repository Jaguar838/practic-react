import img1 from "../../images/brands/brand1.svg";
import img2 from "../../images/brands/brand2.svg";
import img3 from "../../images/brands/brand3.svg";
import img4 from "../../images/brands/brand4.svg";
import img5 from "../../images/brands/brand5.svg";
import img6 from "../../images/brands/brand6.svg";
import img7 from "../../images/brands/brand7.svg";
import img8 from "../../images/brands/brand8.svg";
import img9 from "../../images/brands/brand9.svg";
import img10 from "../../images/brands/brand10.svg";
import img11 from "../../images/brands/brand11.svg";
import img12 from "../../images/brands/brand12.svg";
import img13 from "../../images/brands/brand13.svg";
import img14 from "../../images/brands/brand14.svg";
import img15 from "../../images/brands/brand15.svg";
import img16 from "../../images/brands/brand16.svg";
import img17 from "../../images/brands/brand17.svg";
import img18 from "../../images/brands/brand18.svg";

const brandsLogo = [
  img1,
  img2,
  img3,
  img4,
  img5,
  img6,
  img7,
  img8,
  img9,
  img10,
  img11,
  img12,
  img13,
  img14,
  img15,
  img16,
  img17,
  img18,
];

export default brandsLogo;
