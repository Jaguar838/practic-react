import img1 from "../../images/reviews/google.svg";
import img2 from "../../images/reviews/wayfair.svg";
import img3 from "../../images/reviews/flexport.svg";

const reviewsItems = [
  {
    id: 1,
    img: img1,
    text: "“We can now have meetings in peace.”",
  },
  {
    id: 2,
    img: img2,
    text: "“Amazing private space to get work done.”",
  },
  {
    id: 3,
    img: img3,
    text: "“Our booths are in constant use.”",
  },
];
export default reviewsItems;
